﻿namespace EF_Homework
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Infrastructure;

    using System.Data.Linq.Mapping;
    using System.Data.Linq;
    using System.Reflection;
    using System.Linq;

    using System.Data.Entity.Core.Objects;
    using System.Data.SqlClient;

    public partial class SoftUniEntities : DbContext
    {
        public void GetProjectsOfEmployee(string a, string b)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");

            var EmpFN = new SqlParameter("@EmployeeFirstName", a);
            var EmpLN = new SqlParameter("@EmployeeLastName", b);
            var employeeDetails = this.Database.SqlQuery<clsEmployeeEntity>("GetProjectsOfEmployee @EmployeeFirstName, @EmployeeLastName", EmpFN, EmpLN);

            foreach (var details in employeeDetails)
            {
                Console.WriteLine(details.Name + " - " + details.Description + " , " + String.Format("{0:d/M/yyyy HH:mm:ss}", details.StartDate) + "\n");
            }
        }

        //[Function(Name = "dbo.GetProjectsOfEmployee", IsComposable = false)]
        //public ISingleResult<clsEmployeeEntity> GetProjectsOfEmployee(
        //    [Parameter(Name = "FirstName", DbType = "NVarChar(50)")] string FirstName,
        //    [Parameter(Name = "LastName", DbType = "NVarChar(50)")] string LastName)
        //{
        //    //var ctx = new SoftUniEntities();
        //    IExecuteResult objResult = this.ExecuteMethodCall(this, ((MethodInfo)(MethodInfo.GetCurrentMethod())), FirstName, LastName);
        //    return ((ISingleResult<clsEmployeeEntity>)(objResult.ReturnValue));
        //}



        //public virtual ObjectResult<clsEmployeeEntity> GetProjectsOfEmployee(string employeeFirstName, string employeeLastName)
        //{
        //    var employeeFirstNameParameter = employeeFirstName != null ?
        //        new ObjectParameter("EmployeeFirstName", employeeFirstName) :
        //        new ObjectParameter("EmployeeFirstName", typeof(string));

        //    var employeeLastNameParameter = employeeLastName != null ?
        //        new ObjectParameter("EmployeeLastName", employeeLastName) :
        //        new ObjectParameter("EmployeeLastName", typeof(string));

        //    return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<clsEmployeeEntity>("GetProjectsOfEmployee", employeeFirstNameParameter, employeeLastNameParameter);
        //}


    }
}
