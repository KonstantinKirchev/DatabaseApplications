﻿namespace StudentSystem.Model
{
    public enum ContentType
    {
        Zip,
        Rar,
        Pdf,
        All
    }
}
