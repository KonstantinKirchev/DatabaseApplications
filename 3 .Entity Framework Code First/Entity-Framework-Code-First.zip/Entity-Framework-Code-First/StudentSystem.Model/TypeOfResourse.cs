﻿namespace StudentSystem.Model
{
    public enum TypeOfResourse
    {
        Video,
        Presentation,
        Document,
        Other
    }
}
