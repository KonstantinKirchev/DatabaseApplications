﻿namespace DatabaseManager.MySqlImporter
{
    public struct ImportResult
    {
        public int Inserted { get; set; }

        public int Updated { get; set; }
    }
}
