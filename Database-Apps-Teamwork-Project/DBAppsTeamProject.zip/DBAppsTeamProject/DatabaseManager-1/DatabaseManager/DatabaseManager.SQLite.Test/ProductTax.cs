﻿namespace DatabaseManager.SQLite.Test
{
    public class ProductTax
    {
        public string ProductName { get; set; }

        public float TaxSize { get; set; }
    }
}
