﻿namespace DatabaseManager.UI
{
    internal enum SearchOption
    {
        ExactDate,
        BeforeDate,
        AfterDate,
        BetweenDates
    }
}
