﻿namespace DatabaseManager.VendorReports
{
    public class ProductIncome
    {
        public string ProductName { get; set; }

        public decimal Income { get; set; }
    }
}
