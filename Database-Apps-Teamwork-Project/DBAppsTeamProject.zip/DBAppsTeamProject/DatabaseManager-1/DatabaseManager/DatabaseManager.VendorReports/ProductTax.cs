﻿namespace DatabaseManager.VendorReports
{
    public class ProductTax
    {
        public string ProductName { get; set; }

        public float TaxSize { get; set; }
    }
}
