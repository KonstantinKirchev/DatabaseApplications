﻿namespace DatabaseManager.VendorReports
{
    public class VendorExpense
    {
        public string VendorName { get; set; }

        public decimal Expense { get; set; }
    }
}
